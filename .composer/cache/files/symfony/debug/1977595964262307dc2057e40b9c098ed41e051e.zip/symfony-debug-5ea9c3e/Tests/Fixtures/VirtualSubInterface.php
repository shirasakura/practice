<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

/**
 * @method string subInterfaceMethod()
 */
interface VirtualSubInterface extends VirtualInterface
{
}
